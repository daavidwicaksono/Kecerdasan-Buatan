﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace NQueen
{
    class Program
    {
        const int N = 8;
        static void Main(string[] args)
        {
            int count = 0;
            int[,] board = new int[N, N];


            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    board[i, j] = 0;
                }
            }


            int[] pointer = new int[N];
            for (int i = 0; i < N; i++)
            {
                pointer[i] = -1;
            }


            for (int j = 0; ;)
            {
                pointer[j]++;

                if (pointer[j] == N)
                {
                    board[pointer[j] - 1, j] = 0;
                    pointer[j] = 0;
                    j--;
                    if (j == -1)
                    {
                        Console.WriteLine("\nDavid Aryo W / 672019307");
                        break;
                    }
                }
                else
                {
                    board[pointer[j], j] = 1;
                    if (pointer[j] != 0)
                    {
                        board[pointer[j] - 1, j] = 0;
                    }
                    if (Solusi(board))
                    {
                        j++;
                        if (j == N)
                        {
                            j--;
                            count++;
                            Console.WriteLine("\nPenyelesaian" + count.ToString() + ": \n");
                            for (int p = 0; p < N; p++)
                            {
                                for (int q = 0; q < N; q++)
                                {
                                    if (N == 0)
                                    {
                                        Console.Write(board[p, q] + " ");
                                    }
                                }
                                Console.WriteLine();
                            }
                        }
                    }
                }
            }
        }
        public static bool Solusi(int[,] board)
        {
            //Cek Baris
            for (int i = 0; i < N; i++)
            {
                int sum = 0;
                for (int j = 0; j < N; j++)
                {
                    sum = sum + board[i, j];
                }
                if (sum > 1)
                {
                    return false;
                }
            }
            //Cek Diagonal
            //atas
            for (int i = 0, j = N - 2; j >= 0; j--)
            {
                int sum = 0;
                for (int p = i, q = j; q < N; p++, q++)
                {
                    sum = sum + board[p, q];
                }
                if (sum > 1)
                {
                    return false;
                }
            }
            //bawah
            for (int i = 1, j = 0; i < N - 1; i++)
            {
                int sum = 0;
                for (int p = i, q = j; p < N; p++, q++)
                {
                    sum = sum + board[p, q];
                }
                if (sum > 1)
                {
                    return false;
                }
            }
            //Cek Diagonal 1nya
            //atas
            for (int i = 0, j = 1; j < N; j++)
            {
                int sum = 0;
                for (int p = i, q = j; q >= 0; p++, q--)
                {
                    sum = sum + board[p, q];
                }
                if (sum > 1)
                {
                    return false;
                }
            }
            //bawah
            for (int i = 1, j = N - 1; i < N - 1; i++)
            {
                int sum = 0;
                for (int p = i, q = j; p < N; p++, q--)
                {
                    sum = sum + board[p, q];
                }
                if (sum > 1)
                {
                    return false;
                }
            }
            return true;
        }
    }
}